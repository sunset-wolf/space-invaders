# space-invaders
## Bedienungsanleitung

1.	Öffne das Szenario in Greenfoot
2.	Klicke auf den grünen «Run» Knopf am unteren Ende des Greenfoot Pro-gramms
3.	Wähle mit den Pfeiltasten (unten und oben) das gewünschte Level (Je höher das Level, desto schwieriger sind die Gegner)
4.	Klicke «Enter», das Spiel startet sofort
5.	Bewege das Raumschiff am unteren Ende mit den Pfeiltasten (links und rechts) nach links und rechts, um den Aliens auszuweichen
6.	Drücke die Leertaste (Space) um einen Schuss abzufeuern und Aliens zu eli-minieren.

## Ziel
Dein Ziel ist es, mit möglichst vielen Leben und Punkten alle Gegner eliminiert zu ha-ben.
In der linken, oberen Ecke ist deine Lebensanzeige. Sind keine Raumschiffe in dieser Anzeige vorhanden ist das Spiel zu Ende und du verlierst.
Sind alle Gegner eliminiert hast du das Spiel gewonnen und dein Score wird ange-zeigt.
Der Score erhöht sich mit jeder Elimination eines Aliens. 
Der Score verringert sich, wenn:
-	Ein Alien dein Raumschiff berührt und ein Leben abgezogen wird.
-	Dein Schuss den Weltrand erreicht.

